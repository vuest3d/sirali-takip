import requests
from bs4 import BeautifulSoup
import time
import json
import os
from datetime import datetime

# --- AYARLAR ---
URL = "https://www.yozgateo.org.tr/sirali-esit-dagitim"
KONTROL_ARALIGI_DAKIKA = 30
VERI_DOSYASI = "gecmis_kayitlar.json"
RAPOR_DOSYASI = "index.html"
GEMINI_API_KEY = ""

def veri_cek():
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        response = requests.get(URL, headers=headers, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")
        tum_metin = soup.get_text(separator="\n")
        satirlar = [s.strip() for s in tum_metin.split("\n") if s.strip()]
        
        merkez_listesi = []
        kayit_basladi = False
        for satir in satirlar:
            if satir == "MERKEZ":
                kayit_basladi = True
                continue
            if satir == "AKDAĞMADENİ" and kayit_basladi:
                break
            if kayit_basladi and satir != "+" and len(satir) > 2:
                merkez_listesi.append(satir)
        return merkez_listesi
    except Exception as e:
        print(f"Hata oluştu: {e}")
        return None

def html_sablonu_olustur(tum_veriler_json):
    # CSS Kodu (Normal String - f-string degil)
    css_kodu = """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .timeline-point { position: absolute; left: -6px; top: 24px; width: 12px; height: 12px; border-radius: 50%; background: #3B82F6; border: 2px solid white; }
        .ai-gradient { background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%); }
        .loader { border: 3px solid #f3f3f3; border-radius: 50%; border-top: 3px solid #a855f7; width: 20px; height: 20px; animation: spin 1s linear infinite; display: inline-block; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .dropdown:hover .dropdown-menu { display: block; }
        .modal-enter { animation: modalFadeIn 0.2s ease-out; }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .tab-active { border-bottom: 2px solid #3B82F6; color: #2563EB; font-weight: 600; }
        .tab-inactive { border-bottom: 2px solid transparent; color: #6B7280; }
        .tab-inactive:hover { color: #374151; }
    </style>
    """

    # JS Kodu (Normal String - f-string degil)
    js_kodu = """
    <script>
        function manualRefresh() { window.location.reload(); }

        function parseItem(text) {
            const regex = /^(.*?)(\S+\s+ECZANESİ)$/i;
            const match = text.match(regex);
            if (match) return { header: match[1].trim(), pharmacy: match[2].trim() };
            return { header: "GENEL DAĞITIM", pharmacy: text };
        }

        function getTheme(headerText) {
            const text = headerText.toUpperCase();
            if (text.includes("MOR") || text.includes("TURUNCU")) return { card: "bg-gradient-to-br from-white to-orange-50 border-orange-200 hover:to-orange-100 border-l-orange-500", badge: "bg-orange-100 text-orange-800 border-orange-200", icon: "text-orange-500 bg-orange-50 group-hover:bg-orange-500 group-hover:text-white" };
            if (text.includes("ERİTROPOEİTİN")) return { card: "bg-gradient-to-br from-white to-blue-50 border-blue-200 hover:to-blue-100 border-l-blue-500", badge: "bg-blue-100 text-blue-800 border-blue-200", icon: "text-blue-500 bg-blue-50 group-hover:bg-blue-500 group-hover:text-white" };
            if (text.includes("DİYALİZ")) return { card: "bg-gradient-to-br from-white to-cyan-50 border-cyan-200 hover:to-cyan-100 border-l-cyan-500", badge: "bg-cyan-100 text-cyan-800 border-cyan-200", icon: "text-cyan-500 bg-cyan-50 group-hover:bg-cyan-500 group-hover:text-white" };
            if (text.includes("TÜP BEBEK")) return { card: "bg-gradient-to-br from-white to-pink-50 border-pink-200 hover:to-pink-100 border-l-pink-500", badge: "bg-pink-100 text-pink-800 border-pink-200", icon: "text-pink-500 bg-pink-50 group-hover:bg-pink-500 group-hover:text-white" };
            if (text.includes("CEZAEVİ")) return { card: "bg-gradient-to-br from-white to-red-50 border-red-200 hover:to-red-100 border-l-red-500", badge: "bg-red-100 text-red-800 border-red-200", icon: "text-red-500 bg-red-50 group-hover:bg-red-500 group-hover:text-white" };
            if (text.includes("KANAKINUMAB")) return { card: "bg-gradient-to-br from-white to-indigo-50 border-indigo-200 hover:to-indigo-100 border-l-indigo-500", badge: "bg-indigo-100 text-indigo-800 border-indigo-200", icon: "text-indigo-500 bg-indigo-50 group-hover:bg-indigo-500 group-hover:text-white" };
            if (text.includes("YATAN HASTA")) return { card: "bg-gradient-to-br from-white to-emerald-50 border-emerald-200 hover:to-emerald-100 border-l-emerald-500", badge: "bg-emerald-100 text-emerald-800 border-emerald-200", icon: "text-emerald-500 bg-emerald-50 group-hover:bg-emerald-500 group-hover:text-white" };
            if (text.includes("ANTİ-TNF")) return { card: "bg-gradient-to-br from-white to-teal-50 border-teal-200 hover:to-teal-100 border-l-teal-500", badge: "bg-teal-100 text-teal-800 border-teal-200", icon: "text-teal-500 bg-teal-50 group-hover:bg-teal-500 group-hover:text-white" };
            if (text.includes("İŞ YERİ") || text.includes("HEKİM") || text.includes("SOSYAL") || text.includes("ÇOCUK")) return { card: "bg-gradient-to-br from-white to-violet-50 border-violet-200 hover:to-violet-100 border-l-violet-500", badge: "bg-violet-100 text-violet-800 border-violet-200", icon: "text-violet-500 bg-violet-50 group-hover:bg-violet-500 group-hover:text-white" };
            return { card: "bg-gradient-to-br from-white to-gray-50 border-gray-200 hover:to-gray-100 border-l-gray-500", badge: "bg-gray-100 text-gray-700 border-gray-200", icon: "text-gray-400 bg-gray-50 group-hover:bg-gray-500 group-hover:text-white" };
        }

        function openFullHistoryModal() {
            document.getElementById('full-history-modal').classList.remove('hidden');
            switchHistoryTab('changes'); 
        }

        function closeFullHistoryModal() { document.getElementById('full-history-modal').classList.add('hidden'); }

        function switchHistoryTab(tabName) {
            const contentArea = document.getElementById('history-content-area');
            const tabChanges = document.getElementById('tab-changes');
            const tabSnapshots = document.getElementById('tab-snapshots');

            if(tabName === 'changes') {
                tabChanges.className = 'py-4 px-6 tab-active transition-colors flex items-center gap-2';
                tabSnapshots.className = 'py-4 px-6 tab-inactive transition-colors flex items-center gap-2';
                contentArea.innerHTML = renderChangesView();
            } else {
                tabChanges.className = 'py-4 px-6 tab-inactive transition-colors flex items-center gap-2';
                tabSnapshots.className = 'py-4 px-6 tab-active transition-colors flex items-center gap-2';
                contentArea.innerHTML = renderSnapshotsView();
            }
        }

        function renderChangesView() {
            let html = '<div class="space-y-6">';
            for (let i = 0; i < appData.length; i++) {
                const current = appData[i];
                const prev = (i + 1 < appData.length) ? appData[i+1] : null;
                
                let changesHtml = '';
                if (!prev) {
                    changesHtml = '<div class="p-3 bg-gray-100 rounded text-gray-500 text-sm">İlk sistem kaydı oluşturuldu.</div>';
                } else {
                    const currentSet = new Set(current.liste);
                    const prevSet = new Set(prev.liste);
                    const added = current.liste.filter(x => !prevSet.has(x));
                    const removed = prev.liste.filter(x => !currentSet.has(x));
                    if (added.length === 0 && removed.length === 0) continue; 

                    changesHtml += '<div class="grid grid-cols-1 gap-2">';
                    removed.forEach(item => {
                        const p = parseItem(item);
                        changesHtml += `<div class="flex items-center p-2 bg-red-50 border border-red-100 rounded"><span class="w-6 h-6 rounded-full bg-red-100 text-red-500 flex items-center justify-center mr-3 flex-shrink-0"><i class="fas fa-minus"></i></span><div><div class="text-[10px] text-red-400 font-bold uppercase">Eski Sıradaki Eczane</div><div class="text-gray-700 line-through text-sm"><span class="font-semibold">${p.header}:</span> ${p.pharmacy}</div></div></div>`;
                    });
                    added.forEach(item => {
                        const p = parseItem(item);
                        changesHtml += `<div class="flex items-center p-2 bg-green-50 border border-green-100 rounded"><span class="w-6 h-6 rounded-full bg-green-100 text-green-500 flex items-center justify-center mr-3 flex-shrink-0"><i class="fas fa-plus"></i></span><div><div class="text-[10px] text-green-600 font-bold uppercase">Yeni Sıradaki Eczane</div><div class="text-gray-800 text-sm"><span class="font-semibold">${p.header}:</span> ${p.pharmacy}</div></div></div>`;
                    });
                    changesHtml += '</div>';
                }
                html += `<div class="flex gap-4"><div class="flex flex-col items-center"><div class="w-3 h-3 bg-blue-500 rounded-full mt-2"></div><div class="w-0.5 bg-gray-200 h-full mt-1"></div></div><div class="flex-grow pb-6"><span class="text-sm font-bold text-gray-900 bg-white border px-2 py-1 rounded shadow-sm">${current.tarih}</span><div class="mt-3 bg-white border border-gray-200 rounded-xl p-5 shadow-sm">${changesHtml}</div></div></div>`;
            }
            html += '</div>';
            return html;
        }

        function renderSnapshotsView() {
            let html = '<div class="grid grid-cols-1 gap-6">';
            appData.forEach((record, index) => {
                html += `<div class="border border-gray-200 rounded-xl overflow-hidden shadow-sm bg-white"><div class="bg-gray-50 px-4 py-3 border-b border-gray-200 flex justify-between items-center"><span class="font-bold text-gray-700 flex items-center gap-2"><i class="far fa-calendar-alt"></i> ${record.tarih}</span><span class="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full">${record.liste.length} Kayıt</span></div><div class="p-4 max-h-60 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-2">${record.liste.map(item => { const p = parseItem(item); return `<div class="text-sm border p-2 rounded hover:bg-gray-50"><span class="text-gray-500 text-xs block">${p.header}</span><span class="font-semibold text-gray-800">${p.pharmacy}</span></div>`; }).join('')}</div></div>`;
            });
            html += '</div>';
            return html;
        }

        function showHistory(targetHeader) {
            const historyList = [];
            appData.forEach(record => {
                const foundItem = record.liste.find(item => parseItem(item).header === targetHeader);
                if (foundItem) {
                    const parsed = parseItem(foundItem);
                    historyList.push({ date: record.tarih, pharmacy: parsed.pharmacy });
                }
            });

            document.getElementById('modal-title').innerText = targetHeader;
            const contentDiv = document.getElementById('modal-content');
            
            let html = '';
            if(historyList.length === 0) {
                html = '<div class="p-8 text-center text-gray-500">Bu görev için geçmiş kayıt bulunamadı.</div>';
            } else {
                html = '<div class="divide-y divide-gray-200 bg-white border-b">';
                historyList.forEach((h, index) => {
                    const isLatest = index === 0;
                    html += `<div class="flex items-center p-4 hover:bg-blue-50 transition-colors ${isLatest ? 'bg-blue-50' : ''}"><div class="w-36 flex-shrink-0 flex flex-col"><span class="text-xs font-bold text-gray-400 uppercase">Tarih</span><span class="text-sm font-mono text-gray-600">${h.date}</span></div><div class="flex-grow border-l border-gray-200 pl-4 ml-2"><div class="text-xs font-bold text-gray-400 uppercase mb-0.5">Sıradaki Eczane</div><div class="text-lg font-bold ${isLatest ? 'text-blue-600' : 'text-gray-800'}">${h.pharmacy}${isLatest ? '<span class="ml-2 inline-block bg-blue-100 text-blue-800 text-[10px] px-2 py-0.5 rounded-full align-middle">GÜNCEL</span>' : ''}</div></div></div>`;
                });
                html += '</div>';
            }
            contentDiv.innerHTML = html;
            document.getElementById('history-modal').classList.remove('hidden');
        }

        function closeModal() { document.getElementById('history-modal').classList.add('hidden'); }

        function renderUI(data) {
            if (!data || data.length === 0) return;
            const lastRecord = data[data.length - 1];
            document.getElementById('last-check-display').innerText = lastRecord.tarih;
            const listContainer = document.getElementById('current-list-container');
            listContainer.innerHTML = '';
            document.getElementById('count-display').innerText = lastRecord.liste.length + ' Kayıt';

            lastRecord.liste.forEach(item => {
                const parsed = parseItem(item);
                const theme = getTheme(parsed.header);
                const el = document.createElement('div');
                el.className = `border rounded-xl p-4 shadow-sm hover:shadow-md transition-all border-l-4 group cursor-pointer active:scale-[0.98] select-none ${theme.card}`;
                const safeHeader = parsed.header.replace(/'/g, "\\'");
                el.setAttribute('onclick', `showHistory('${safeHeader}')`);
                el.innerHTML = `<div class="flex justify-between items-start"><div class="w-full"><div class="mb-2"><span class="${theme.badge} border px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wide inline-block shadow-sm">${parsed.header}</span></div><div class="text-lg font-bold text-gray-800 group-hover:text-blue-700 transition-colors pl-1">${parsed.pharmacy}</div></div><div class="ml-3 flex-shrink-0 pt-1"><div class="w-8 h-8 rounded-full flex items-center justify-center transition-colors shadow-sm ${theme.icon}"><i class="fas fa-history"></i></div></div></div>`;
                listContainer.appendChild(el);
            });

            const historyContainer = document.getElementById('history-container');
            historyContainer.innerHTML = '';

            for (let i = data.length - 1; i >= 0; i--) {
                const current = data[i];
                const prev = i > 0 ? data[i-1] : null;
                let title = "Değişiklik Tespit Edildi";
                let color = "green";
                let detailsHtml = "";

                if (!prev) {
                    title = "Sistem Başlatıldı / Yedek Yüklendi";
                    color = "gray";
                    detailsHtml = '<p class="text-sm text-gray-600">İlk kayıt.</p>';
                } else if (JSON.stringify(current.liste) === JSON.stringify(prev.liste)) {
                    continue; 
                } else {
                    const oldSet = new Set(prev.liste);
                    const newSet = new Set(current.liste);
                    const added = current.liste.filter(x => !oldSet.has(x));
                    const removed = prev.liste.filter(x => !newSet.has(x));
                    detailsHtml += '<div class="grid grid-cols-1 gap-2 mt-2">';
                    removed.forEach(item => { detailsHtml += `<div class="bg-red-50 p-2 rounded border border-red-100 text-xs flex items-center"><span class="w-4 h-4 rounded bg-red-100 text-red-600 flex items-center justify-center mr-2"><i class="fas fa-minus"></i></span><span class="line-through text-gray-500">${item}</span></div>`; });
                    added.forEach(item => { detailsHtml += `<div class="bg-green-50 p-2 rounded border border-green-100 text-xs flex items-center"><span class="w-4 h-4 rounded bg-green-100 text-green-600 flex items-center justify-center mr-2"><i class="fas fa-plus"></i></span><span class="font-bold text-gray-800">${item}</span></div>`; });
                    detailsHtml += '</div>';
                }

                const historyItem = document.createElement('div');
                historyItem.className = 'ml-6 relative';
                historyItem.innerHTML = `<div class="timeline-point bg-${color}-500"></div><div class="flex items-center mb-1"><span class="text-sm font-bold text-gray-900">${current.tarih}</span></div><div class="bg-white border border-gray-200 rounded-lg p-4 shadow-sm"><p class="text-sm font-medium text-gray-800 mb-1">${title}</p>${detailsHtml}</div>`;
                historyContainer.appendChild(historyItem);
            }
        }

        function handleFileUpload(input) {
            const file = input.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const json = JSON.parse(e.target.result);
                    if (Array.isArray(json)) {
                        appData = json; renderUI(appData); alert("Yedek başarıyla yüklendi!");
                    } else { alert("Hatalı format."); }
                } catch (error) { alert("Hata: " + error); }
            };
            reader.readAsText(file);
        }
        function downloadCSV() {
            let csvContent = "\\uFEFFTarih,Liste İçeriği\\n"; 
            appData.forEach(record => { record.liste.forEach(item => { let cleanItem = item.replace(/"/g, '""'); csvContent += `"${record.tarih}","${cleanItem}"\n`; }); });
            saveFile(new Blob([csvContent], { type: 'text/csv;charset=utf-8;' }), "dagitim_gecmisi.csv");
        }
        function downloadJSON() { saveFile(new Blob([JSON.stringify(appData, null, 4)], { type: 'application/json' }), "dagitim_yedek.json"); }
        function saveFile(blob, filename) { const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.setAttribute("href", url); link.setAttribute("download", filename); document.body.appendChild(link); link.click(); document.body.removeChild(link); }
        
        function toggleResponseArea(show) { const el = document.getElementById('ai-response-container'); if(show) { el.classList.remove('hidden'); document.getElementById('ai-loader').classList.remove('hidden'); document.getElementById('ai-result').innerHTML = ''; } else { document.getElementById('ai-loader').classList.add('hidden'); } }
        
        async function callGeminiAPI(prompt) {
            toggleResponseArea(true);
            try {
                const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
                });
                const data = await response.json();
                if (data.error) throw new Error(data.error.message);
                const aiText = data.candidates[0].content.parts[0].text;
                document.getElementById('ai-result').innerHTML = marked.parse(aiText);
            } catch (error) {
                document.getElementById('ai-result').innerHTML = `<span class="text-red-500">Hata: ${error.message}</span>`;
            } finally { document.getElementById('ai-loader').classList.add('hidden'); }
        }

        async function analyzeList() { await callGeminiAPI(`Bu listeyi analiz et: 1. Hangi eczane hangi görevi almış? 2. Birden fazla görevi olan var mı?\\n\\n` + getCurrentListData()); }
        async function askGemini() { const q = document.getElementById('userQuery').value; if (!q) return; await callGeminiAPI(`LİSTE:\\n` + getCurrentListData() + `\\n\\nSORU: ${q}\\nKısa ve net cevapla.`); }
        document.getElementById('userQuery').addEventListener('keypress', function (e) { if (e.key === 'Enter') askGemini(); });
        
        renderUI(appData);
    </script>
    """

    # HTML Sablonu
    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sıralı Eşit Dağıtım Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    {css_kodu}
</head>
<body class="bg-gray-50 min-h-screen p-4 md:p-8">
    <!-- DETAYLI GEÇMİŞ MODALI -->
    <div id="full-history-modal" class="fixed inset-0 bg-gray-900 bg-opacity-60 z-50 hidden flex items-center justify-center p-4 backdrop-blur-sm" onclick="if(event.target === this) closeFullHistoryModal()">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col modal-enter overflow-hidden">
            <div class="bg-gray-50 border-b border-gray-200 p-4 flex justify-between items-center">
                <div class="flex items-center gap-3"><div class="bg-blue-100 p-2 rounded-lg text-blue-600"><i class="fas fa-history text-xl"></i></div><div><h2 class="text-xl font-bold text-gray-800">Geçmiş Kayıt İnceleme</h2><p class="text-sm text-gray-500">Sistem tarafından kaydedilen tüm değişiklikler</p></div></div>
                <button onclick="closeFullHistoryModal()" class="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-200 transition-colors"><i class="fas fa-times text-xl"></i></button>
            </div>
            <div class="flex border-b border-gray-200 px-6 bg-white">
                <button onclick="switchHistoryTab('changes')" id="tab-changes" class="py-4 px-6 tab-active transition-colors flex items-center gap-2"><i class="fas fa-exchange-alt"></i> Değişim Günlüğü</button>
                <button onclick="switchHistoryTab('snapshots')" id="tab-snapshots" class="py-4 px-6 tab-inactive transition-colors flex items-center gap-2"><i class="fas fa-layer-group"></i> Tam Liste Arşivi</button>
            </div>
            <div class="flex-grow overflow-y-auto bg-gray-50 p-6" id="history-content-area"></div>
        </div>
    </div>

    <!-- GÖREV GEÇMİŞİ MODALI -->
    <div id="history-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4 backdrop-blur-sm" onclick="if(event.target === this) closeModal()">
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden transform transition-all modal-enter flex flex-col max-h-[80vh]">
            <div class="bg-blue-600 p-4 flex justify-between items-center flex-shrink-0">
                <div class="flex items-center text-white"><div class="w-8 h-8 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-3"><i class="fas fa-history"></i></div><div><h3 class="font-bold text-lg leading-tight" id="modal-title">Görev Geçmişi</h3><p class="text-blue-100 text-xs">Sıralama Değişim Logları</p></div></div>
                <button onclick="closeModal()" class="text-blue-100 hover:text-white hover:bg-blue-700 p-2 rounded-full transition-colors"><i class="fas fa-times text-xl"></i></button>
            </div>
            <div class="overflow-y-auto p-0 bg-gray-50 flex-grow" id="modal-content"></div>
        </div>
    </div>

    <div class="max-w-screen-2xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6 flex flex-col md:flex-row justify-between items-center border-b-4 border-blue-500">
            <div class="mb-4 md:mb-0">
                <h1 class="text-2xl font-bold text-gray-800"><i class="fas fa-history text-blue-500 mr-2"></i>Sıralı Eşit Dağıtım Takip</h1>
                <p class="text-gray-500 text-sm mt-1">Yozgat Eczacı Odası - Merkez Bölgesi</p>
            </div>
            <div class="flex flex-col md:flex-row gap-4 items-end md:items-center">
                <div class="flex gap-2 items-center">
                    <button onclick="window.location.reload()" class="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center shadow-sm group"><i class="fas fa-sync-alt mr-2 group-hover:animate-spin"></i>Listeyi Yenile</button>
                    <div class="h-8 w-px bg-gray-200 mx-1"></div>
                    <input type="file" id="importFile" accept=".json" class="hidden" onchange="handleFileUpload(this)">
                    <button onclick="document.getElementById('importFile').click()" class="bg-blue-50 hover:bg-blue-100 text-blue-600 border border-blue-200 px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center"><i class="fas fa-upload mr-2"></i>Yedek Yükle</button>
                    <div class="h-8 w-px bg-gray-200 mx-1"></div>
                    <div class="relative dropdown">
                        <button class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center shadow-sm"><i class="fas fa-download mr-2"></i>Yedek İndir<i class="fas fa-chevron-down ml-2 text-xs opacity-70"></i></button>
                        <div class="dropdown-menu absolute right-0 pt-2 w-48 hidden z-50">
                            <div class="bg-white rounded-lg shadow-xl border border-gray-100 overflow-hidden">
                                <button onclick="downloadCSV()" class="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 border-b border-gray-50 flex items-center transition-colors"><div class="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center mr-3"><i class="fas fa-file-excel"></i></div><div><div class="font-semibold">Excel İndir</div><div class="text-xs text-gray-400">.csv formatı</div></div></button>
                                <button onclick="downloadJSON()" class="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 flex items-center transition-colors"><div class="w-8 h-8 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mr-3"><i class="fas fa-file-code"></i></div><div><div class="font-semibold">JSON İndir</div><div class="text-xs text-gray-400">.json formatı</div></div></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right hidden md:flex flex-col items-end pl-4 border-l border-gray-200">
                    <div class="inline-flex items-center bg-green-50 text-green-700 text-xs px-2 py-1 rounded-full border border-green-100 shadow-sm mb-2"><span class="w-2 h-2 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>Bot Aktif</div>
                    <div class="text-sm text-gray-500 leading-tight">Son Kontrol</div>
                    <div class="font-mono font-bold text-gray-700" id="last-check-display">--</div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- SOL PANEL -->
            <div class="lg:col-span-4 space-y-6 lg:order-1">
                <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-purple-100">
                    <div class="ai-gradient p-4 text-white">
                        <h2 class="font-bold text-lg flex items-center"><i class="fas fa-sparkles mr-2"></i>Yapay Zeka Asistanı</h2>
                    </div>
                    <div class="p-5 space-y-4">
                        <button onclick="analyzeList()" class="w-full bg-purple-50 hover:bg-purple-100 text-purple-700 font-semibold py-2 px-4 rounded-lg border border-purple-200 transition-colors flex items-center justify-center gap-2 text-sm"><i class="fas fa-chart-pie"></i> Listeyi Analiz Et ✨</button>
                        <div class="relative">
                            <input type="text" id="userQuery" placeholder="Örn: Mor reçete kimde?" class="w-full pl-3 pr-10 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-purple-400">
                            <button onclick="askGemini()" class="absolute inset-y-0 right-0 px-3 text-purple-600 hover:text-purple-800"><i class="fas fa-paper-plane"></i></button>
                        </div>
                        <div id="ai-response-container" class="hidden border-t border-gray-100 pt-3 mt-2">
                            <div class="flex justify-between items-center mb-2"><span class="text-xs font-bold text-purple-600">CEVAP</span><span id="ai-loader" class="loader hidden"></span></div>
                            <div id="ai-result" class="text-sm text-gray-700 prose prose-sm max-w-none bg-gray-50 p-3 rounded-lg"></div>
                        </div>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6 h-full flex flex-col">
                    <div class="flex justify-between items-center mb-6 border-b pb-2">
                        <h2 class="font-bold text-lg text-gray-800"><i class="fas fa-clock text-orange-500 mr-2"></i>Değişim Geçmişi</h2>
                        <button onclick="openFullHistoryModal()" class="text-xs bg-blue-50 text-blue-600 hover:bg-blue-100 px-2 py-1 rounded transition-colors flex items-center gap-1"><i class="fas fa-search-plus"></i> Detaylı İncele</button>
                    </div>
                    <div class="relative border-l-2 border-gray-200 ml-3 space-y-8 pb-4 flex-grow overflow-y-auto max-h-[400px] pr-2" id="history-container"></div>
                </div>
            </div>

            <!-- SAĞ PANEL -->
            <div class="lg:col-span-8 lg:order-2">
                <div class="bg-white rounded-xl shadow-sm p-5 h-full">
                    <h2 class="font-bold text-lg mb-4 text-gray-800 border-b pb-2 flex justify-between items-center">
                        <span><i class="fas fa-list-ul text-green-500 mr-2"></i>Güncel Liste</span>
                        <span class="text-xs bg-gray-100 text-gray-500 py-1 px-2 rounded" id="count-display">0 Kayıt</span>
                    </h2>
                    <div class="text-xs text-gray-400 mb-4 flex items-center bg-gray-50 p-2 rounded"><i class="fas fa-info-circle mr-2 text-blue-400"></i>Detaylı geçmişini görmek için görev kartlarının üzerine tıklayabilirsiniz.</div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[800px] overflow-y-auto pr-2" id="current-list-container"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Python degiskenlerini JS'e enjekte ediyoruz:
        const apiKey = "{GEMINI_API_KEY}";
        let appData = {tum_veriler_json};
        
        // JS fonksiyonlari burada baslar...
    </script>
    {js_kodu}
</body>
</html>"""
    return html

def rapor_olustur(gecmis_veriler):
    """Verileri kullanarak HTML raporu oluşturur."""
    tum_veriler_json = json.dumps(gecmis_veriler, ensure_ascii=False)
    full_html = html_sablonu_olustur(tum_veriler_json)
    
    with open(RAPOR_DOSYASI, "w", encoding="utf-8") as f:
        f.write(full_html)
    print(f"[{datetime.now().strftime('%H:%M')}] Rapor güncellendi: {RAPOR_DOSYASI}")

def main():
    print(f"Takip Botu Başlatıldı. Kontrol Aralığı: {KONTROL_ARALIGI_DAKIKA} dakika.")
    
    gecmis_veriler = []
    if os.path.exists(VERI_DOSYASI):
        try:
            with open(VERI_DOSYASI, "r", encoding="utf-8") as f:
                gecmis_veriler = json.load(f)
        except:
            gecmis_veriler = []

    while True:
        simdi = datetime.now().strftime("%d.%m.%Y %H:%M")
        print(f"[{simdi}] Site kontrol ediliyor...")
        yeni_liste = veri_cek()
        
        if yeni_liste:
            degisiklik_var = False
            if not gecmis_veriler:
                degisiklik_var = True
            else:
                son_liste = gecmis_veriler[-1]["liste"]
                if set(yeni_liste) != set(son_liste):
                    degisiklik_var = True
            
            if degisiklik_var:
                print(f"!!! DEĞİŞİKLİK TESPİT EDİLDİ !!!")
                kayit = { "tarih": simdi, "liste": yeni_liste }
                gecmis_veriler.append(kayit)
                with open(VERI_DOSYASI, "w", encoding="utf-8") as f:
                    json.dump(gecmis_veriler, f, ensure_ascii=False, indent=4)
                rapor_olustur(gecmis_veriler)
            else:
                print("Değişiklik yok. Rapor arayüzü yenileniyor...")
                rapor_olustur(gecmis_veriler)
        else:
            print("Veri çekilemedi.")

        # GitHub Actions'ta döngüyü kırmak gerekir, aksi halde sonsuza kadar çalışır ve zaman aşımına uğrar.
        # Yerel testler için while True kalabilir ama GitHub Actions tek seferlik çalışmalıdır.
        # Bu yüzden burada 'break' ekliyorum.
        break 

if __name__ == "__main__":
    main()
